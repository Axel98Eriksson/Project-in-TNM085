function [x,y] = drawField()

x = [-1 1 1 -1 -1]; 
y = [0 0 8 8 0]; 
end